class TradeModel {
  List<Data>? data;

  TradeModel({this.data});

  TradeModel.fromJson(Map<String, dynamic> json) {
    if (json['data'] != null) {
      data = <Data>[];
      json['data'].forEach((v) {
        data!.add(Data.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Data {
  String? asset;
  String? last;
  String? bid;
  String? ask;
  String? change;
  String? changePercent;
  String? open;
  String? high;
  String? low;

  Data(
      {this.asset,
      this.last,
      this.bid,
      this.ask,
      this.change,
      this.changePercent,
      this.open,
      this.high,
      this.low});

  Data.fromJson(Map<String, dynamic> json) {
    asset = json['asset'];
    last = json['last'];
    bid = json['bid'];
    ask = json['ask'];
    change = json['change'];
    changePercent = json['changePercent'];
    open = json['open'];
    high = json['high'];
    low = json['low'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['asset'] = asset;
    data['last'] = last;
    data['bid'] = bid;
    data['ask'] = ask;
    data['change'] = change;
    data['changePercent'] = changePercent;
    data['open'] = open;
    data['high'] = high;
    data['low'] = low;
    return data;
  }
}
