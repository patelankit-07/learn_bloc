// void main() {
//   Student student1 = Student();
//   student1.name = "Flutter";
//   student1.email = "flutter@example.com";
//   student1.age = 20;
//   student1.studentId = 25;
//
//   Student student2 = Student();
//   student2.name = "Viki Patel";
//   student2.email = "viki@example.com";
//   student2.age = 20;
//   student2.studentId = 25;
//
//   Student student3 = Student();
//   student3.name = "Ankit Patel";
//   student3.email = "ankit@example.com";
//   student3.age = 20;
//   student3.studentId = 25;
//
//   student1.displayInformation();
//   student2.displayInformation();
//   student3.displayInformation();
//
//   student1.updateData('Flutter Developer','Flutter122@gmail.com',25);
//
// }
//
// class Student {
//   String? name;
//   String? email;
//   int? age;
//   int? studentId;
//
//   displayInformation() {
//     print("Name: $name");
//     print("Email: $email");
//     print("Age: $age");
//     print("Student ID: $studentId");
//   }
//
//   updateData(String updateName, String updateEmail, int updateAge,) {
//     name = updateName;
//     email = updateEmail;
//     age = updateAge;
//     print("Student data updated successfully.\n Name:- $name \n Email:- $email \n Age:- $age");
//   }
// }
