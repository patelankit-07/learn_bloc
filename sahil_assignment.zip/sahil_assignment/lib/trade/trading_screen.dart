import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:sahil_assignment/trade/try_screen.dart';
import 'package:shimmer/shimmer.dart';
import '../model/trade_model.dart';

class TradeChartPage extends StatefulWidget {
  const TradeChartPage({super.key});

  @override
  TradeChartPageState createState() => TradeChartPageState();
}

class TradeChartPageState extends State<TradeChartPage> {
  List<FlSpot> dataPoints = [];
  Random random = Random();
  late Timer updateTimer;
  late Timer countdownTimer;
  late double currentValue;
  String _selectedOption = 'EUR/USD';
  int countdown = 30;
  late Future<List<Data>> futureTradeData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _generateInitialData();
    updateTimer = Timer.periodic(const Duration(seconds: 2), (timer) {
      _updateData();
    });
    countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateCountdown();
    });

    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        _isLoading = false;
      });
    });
  }

  @override
  void dispose() {
    updateTimer.cancel();
    countdownTimer.cancel();
    super.dispose();
  }

  void _generateInitialData() {
    currentValue = random.nextDouble() * 100 - 80;
    for (int i = 0; i < 100; i++) {
      dataPoints.add(FlSpot(i.toDouble(), currentValue));
      _updateValue();
    }
  }

  void _updateValue({double change = 0}) {
    double randomChange = (random.nextDouble() - 0.5) * 5;
    currentValue = (currentValue + change + randomChange).clamp(-80.0, 20.0);
  }

  void _updateData() {
    setState(() {
      _updateValue();
      dataPoints.removeAt(0);
      dataPoints.add(FlSpot(99, currentValue));
      for (int i = 0; i < dataPoints.length; i++) {
        dataPoints[i] = FlSpot(i.toDouble(), dataPoints[i].y);
      }
    });
  }

  void _updateCountdown() {
    setState(() {
      if (countdown > 0) {
        countdown--;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double chartHeight = MediaQuery.of(context).size.height - 180;
    double yPosition = ((currentValue + 80) / 100) * chartHeight;

    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.grey[900],
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: DropdownButton<String>(
                    value: _selectedOption,
                    onChanged: (String? newValue) {
                      setState(() {
                        _selectedOption = newValue!;
                      });
                    },
                    dropdownColor: Colors.grey[850],
                    style: const TextStyle(color: Colors.white),
                    items: <String>['EUR/USD', 'GBP/USD',]
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(value),
                      );
                    }).toList(),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const HomeScreen(),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(right: 22),
                    child: Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: Colors.grey[850],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.person, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Center(
                  child: _isLoading
                      ? Shimmer.fromColors(
                          baseColor: Colors.grey[800]!,
                          highlightColor: Colors.grey[500]!,
                          child: Container(
                            height: 800,
                            color: Colors.grey[850],
                          ),
                        )
                      : Stack(
                          children: [
                            LineChart(
                              LineChartData(
                                lineBarsData: [
                                  LineChartBarData(
                                    spots: dataPoints,
                                    isCurved: true,
                                    color: Colors.blue,
                                    barWidth: 2,
                                    isStrokeCapRound: true,
                                    belowBarData: BarAreaData(
                                      show: true,
                                      gradient: LinearGradient(
                                        colors: [
                                          Colors.blue.withOpacity(0.3),
                                          Colors.transparent,
                                        ],
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                      ),
                                    ),
                                    dotData: const FlDotData(show: false),
                                    shadow: const Shadow(
                                      color: Colors.black,
                                      blurRadius: 5,
                                      offset: Offset(0, 3),
                                    ),
                                  ),
                                ],
                                titlesData: FlTitlesData(
                                  rightTitles: AxisTitles(
                                    sideTitles: SideTitles(
                                      showTitles: true,
                                      reservedSize: 50,
                                      getTitlesWidget: (value, meta) {
                                        return Padding(
                                          padding:
                                              const EdgeInsets.only(left: 25),
                                          child: Text(
                                            value.toInt().toString(),
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 10,
                                            ),
                                          ),
                                        );
                                      },
                                    ),
                                  ),
                                  bottomTitles: const AxisTitles(
                                      sideTitles:
                                          SideTitles(showTitles: false)),
                                  leftTitles: const AxisTitles(
                                      sideTitles:
                                          SideTitles(showTitles: false)),
                                  topTitles: const AxisTitles(
                                      sideTitles:
                                          SideTitles(showTitles: false)),
                                ),
                                borderData: FlBorderData(show: false),
                                gridData: FlGridData(
                                  show: true,
                                  drawVerticalLine: true,
                                  horizontalInterval: 15,
                                  verticalInterval: 35,
                                  getDrawingHorizontalLine: (value) {
                                    return FlLine(
                                      color: Colors.white.withOpacity(0.1),
                                      strokeWidth: 1,
                                    );
                                  },
                                  getDrawingVerticalLine: (value) {
                                    return FlLine(
                                      color: Colors.white.withOpacity(0.1),
                                      strokeWidth: 1,
                                    );
                                  },
                                ),
                                extraLinesData: ExtraLinesData(
                                  horizontalLines: [
                                    HorizontalLine(
                                      y: currentValue,
                                      color: Colors.white,
                                      strokeWidth: 1,
                                    ),
                                  ],
                                ),
                                minX: 20,
                                maxX: 130,
                                minY: -100,
                                maxY: 20,
                              ),
                            ),
                            Positioned(
                              right: 1,
                              top: chartHeight - yPosition,
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: Text(
                                  currentValue.toStringAsFixed(3),
                                  style: const TextStyle(
                                      color: Colors.black, fontSize: 12),
                                ),
                              ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOptionCard(String title, IconData icon, StateSetter setState) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedOption = title;
        });
        Navigator.pop(context);
      },
      child: Card(
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(icon, color: Colors.blue),
              const SizedBox(width: 8),
              Text(title),
            ],
          ),
        ),
      ),
    );
  }
}
