// part of 'todo_bloc.dart';
//
//
// abstract class TodoEvent extends Equatable {
//
//   @Override
//
//   List<Object> get props => [];
//
// }
//
// class AddTodoEvent extends TodoEvent {}